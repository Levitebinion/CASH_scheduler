# CASH Scheduler - Separate Feature Prototype

This is a standalone Qt 6 application placed in its own folder. It does not change or depend on any existing `qt/`, `src/`, or `test/` files.

Features: add/edit/delete events, view all, search by title, event counter, highlighted dates, upcoming five events, jump to today, JSON persistence, get-ready/leave notifications while running, and overlap warnings (each event is assumed to last one hour).

## Build

From the repository root:

```bash
cmake -S CASH_Upgrades -B CASH_Upgrades/build
cmake --build CASH_Upgrades/build
```

Run `CASH_Upgrades/build/CASHUpgrades` on Linux, or the corresponding executable on Windows.

Requires Qt 6 Widgets, CMake 3.16+, and a C++20 compiler.

This application has its own event storage and is not yet integrated with the existing team's calendar backend. Existing project files remain unchanged. Reminder delivery depends on the application running and on system tray support. The code has not been compiled in the team's environment.
